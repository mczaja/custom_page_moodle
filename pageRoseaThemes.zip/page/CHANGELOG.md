# CHANGELOG

## [1.0.0] - 2025-04-02
### Added
- Initial release